<?php
	get_header();
?>
<div class="xintheme-container container">
	<div class="row">
		<div class="content-area list-side col-md-12">
			<?php get_template_part("template-parts/content", "list");?>
		</div>
	</div>
</div>
<?php get_footer();?>